# Zentra Minigames
Plugin minigame Purpur/Paper 1.21+. Build otomatis lewat GitHub Actions (tab Actions -> Artifacts).
