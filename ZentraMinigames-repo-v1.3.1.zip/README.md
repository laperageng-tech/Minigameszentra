# Zentra Minigames
Plugin minigame Purpur/Paper 1.21+. Build otomatis lewat GitHub Actions (tab Actions -> Artifacts).

## Baru di 1.1.0
- **Practice PvP**: arena datar luas (maks 40 pemain), respawn instan, proteksi spawn 3 detik, kill streak, papan skor, hologram Top Kill.
  - Klik Practice PvP di menu -> muncul menu pilih kit (tidak langsung teleport): Crystal PvP, Mace, Sword, NoDebuff.
  - Item Ganti Kit di hotbar untuk pindah kit. Perintah cepat: `/zm practice <crystal|mace|sword|nodebuff>`.
- **Ruang tunggu baru**: scoreboard, bossbar progres, actionbar animasi + tips, hologram status arena, partikel, item Aturan / Panggil Teman (undangan klik-gabung) / Vote Mulai Cepat.
- **Menu utama baru** 54 slot dengan status tiap game; klik kanan pada game = lihat aturan.
- Hitung mundur dengan warna & suara bertahap, kartu hasil pemenang.
- Kit Mace sekarang Mace + Tombak Netherite (Lunge), butuh server 1.21.11+ (Paper API dinaikkan ke 1.21.11).
- **Bot latihan** di Practice: Husk berarmor sesuai kit, tingkat Mudah/Sedang/Sulit (tombol di menu kit atau `/zm bot <mati|mudah|sedang|sulit>`). Bot hanya menyerang pemiliknya dan respawn setelah dikalahkan.
- Perbaikan Duel: bucket air dihapus dari kit Mace (tidak bisa dipakai di arena), fall damage dimatikan.

Catatan upgrade: `build-version` di config dinaikkan ke 2. Kalau config.yml lama sudah ada di server, tambahkan baris `practice` di bagian `games:` dan jalankan `/zm build all` agar arena dibangun ulang.
