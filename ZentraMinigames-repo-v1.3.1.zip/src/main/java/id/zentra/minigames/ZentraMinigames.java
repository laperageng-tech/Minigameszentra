package id.zentra.minigames;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;

public final class ZentraMinigames extends JavaPlugin {
    private GameManager manager;
    private NamespacedKey itemKey;
    private File dataFile;
    private YamlConfiguration data;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        itemKey = new NamespacedKey(this, "lobby_item");
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        manager = new GameManager(this);
        getServer().getPluginManager().registerEvents(new GameListener(this, manager), this);
        MinigamesCommand cmd = new MinigamesCommand(this, manager);
        getCommand("zm").setExecutor(cmd);
        getCommand("zm").setTabCompleter(cmd);
        // Tunggu Multiverse selesai memuat world
        Bukkit.getScheduler().runTaskLater(this, () -> tryInit(0), 60L);
    }

    private void tryInit(int attempt) {
        String wn = getConfig().getString("world", "pvp");
        World w = Bukkit.getWorld(wn);
        if (w == null) {
            if (attempt < 30) {
                Bukkit.getScheduler().runTaskLater(this, () -> tryInit(attempt + 1), 100L);
            } else {
                getLogger().severe("World '" + wn + "' tidak ditemukan. Pastikan world itu sudah dibuat di Multiverse, lalu restart server.");
            }
            return;
        }
        manager.init(w);
    }

    @Override
    public void onDisable() {
        if (manager != null) manager.shutdown();
    }

    public GameManager manager() { return manager; }

    // ---------- data pembangunan arena ----------
    public YamlConfiguration data() { return data; }
    public boolean isBuilt(String id) { return data.getBoolean("built." + id, false); }
    public void markBuilt(String id, boolean v) { data.set("built." + id, v); saveData(); }
    public void saveData() {
        try { data.save(dataFile); } catch (IOException ex) { getLogger().warning("Gagal menyimpan data.yml: " + ex.getMessage()); }
    }

    // ---------- util ----------
    public void setScale(Player p, double v) {
        Attribute a = Registry.ATTRIBUTE.get(NamespacedKey.minecraft("scale"));
        if (a == null) return;
        AttributeInstance ai = p.getAttribute(a);
        if (ai != null && ai.getBaseValue() != v) ai.setBaseValue(v);
    }

    /** Item hotbar interaktif (Aturan, Panggil Teman, Vote, Keluar, Ganti Kit). */
    public ItemStack lobbyItem(Material mat, String name, String id, String... lore) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.displayName(Msg.c(name));
        if (lore.length > 0) {
            java.util.List<net.kyori.adventure.text.Component> l = new java.util.ArrayList<>();
            for (String s : lore) l.add(Msg.c(s));
            m.lore(l);
        }
        m.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, id);
        it.setItemMeta(m);
        return it;
    }

    public ItemStack leaveItem() {
        return lobbyItem(Material.RED_DYE, "&c&lKeluar &7(klik kanan)", "leave", "&7Kembali ke tempat semula");
    }

    /** id item interaktif, atau null kalau bukan item plugin. */
    public String itemId(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING);
    }
}
