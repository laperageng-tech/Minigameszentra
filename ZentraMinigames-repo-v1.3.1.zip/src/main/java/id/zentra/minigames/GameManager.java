package id.zentra.minigames;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import net.kyori.adventure.text.Component;
import org.bukkit.Sound;
import org.bukkit.inventory.ItemFlag;

import java.util.*;

public final class GameManager {
    public static final List<String> KEYS = List.of("sumo", "tnttag", "crumble", "colorrush", "pillars", "tinyhunt", "duel", "practice");

    public static final class MenuHolder implements InventoryHolder {
        public Inventory inv;
        public final Map<Integer, String> keys = new HashMap<>();
        @Override public Inventory getInventory() { return inv; }
    }

    private final ZentraMinigames plugin;
    private final Map<String, List<Game>> games = new LinkedHashMap<>();
    private final Map<UUID, Game> inGame = new HashMap<>();
    private final Map<UUID, Integer> botPref = new HashMap<>();
    private final Deque<Game> buildQueue = new ArrayDeque<>();
    private final Set<String> queued = new HashSet<>();
    private boolean building;
    private World world;

    public GameManager(ZentraMinigames plugin) { this.plugin = plugin; }

    public World world() { return world; }

    public void init(World w) {
        world = w;
        FileConfiguration c = plugin.getConfig();
        int baseX = c.getInt("arena.x", 30000), baseZ = c.getInt("arena.z", 30000), baseY = c.getInt("arena.y", 150);
        int ver = c.getInt("build-version", 1);
        if (plugin.data().getInt("build-version", 0) != ver) {
            plugin.data().set("built", null);
            plugin.data().set("build-version", ver);
            plugin.saveData();
        }
        int i = 0;
        for (String key : KEYS) {
            if (!c.getBoolean("games." + key + ".enabled", true)) continue;
            int n = Math.max(1, c.getInt("games." + key + ".instances", key.equals("practice") ? 1 : 2));
            List<Game> list = new ArrayList<>();
            for (int j = 0; j < n; j++) {
                Game g = create(key, j, baseX + i * 400, baseY, baseZ + j * 400);
                list.add(g);
                g.activate();
                if (plugin.isBuilt(g.id())) g.state = Game.State.WAITING;
                else queueBuild(g);
            }
            games.put(key, list);
            i++;
        }
        plugin.getLogger().info("Zentra Minigames siap di world '" + w.getName() + "'. Arena yang belum ada akan dibangun otomatis.");
        pump();
    }

    private Game create(String key, int j, int cx, int by, int cz) {
        return switch (key) {
            case "sumo" -> new SumoGame(plugin, j, cx, by, cz);
            case "tnttag" -> new TntTagGame(plugin, j, cx, by, cz);
            case "crumble" -> new CrumbleRunGame(plugin, j, cx, by, cz);
            case "colorrush" -> new ColorRushGame(plugin, j, cx, by, cz);
            case "pillars" -> new PillarsGame(plugin, j, cx, by, cz);
            case "tinyhunt" -> new TinyHuntGame(plugin, j, cx, by, cz);
            case "duel" -> new DuelGame(plugin, j, cx, by, cz);
            case "practice" -> new PracticeGame(plugin, j, cx, by, cz);
            default -> throw new IllegalArgumentException(key);
        };
    }

    private void queueBuild(Game g) {
        if (!queued.add(g.id())) return;
        g.state = Game.State.RESETTING;
        buildQueue.add(g);
    }

    private void pump() {
        if (building) return;
        Game g = buildQueue.poll();
        if (g == null) return;
        building = true;
        plugin.getLogger().info("Membangun arena " + g.id() + " ...");
        g.build(() -> {
            plugin.markBuilt(g.id(), true);
            queued.remove(g.id());
            g.state = Game.State.WAITING;
            building = false;
            plugin.getLogger().info("Arena " + g.id() + " selesai.");
            pump();
        });
    }

    public void rebuild(String key) {
        for (Map.Entry<String, List<Game>> en : games.entrySet()) {
            if (!key.equals("all") && !en.getKey().equals(key)) continue;
            for (Game g : en.getValue()) {
                if (!g.players.isEmpty()) continue;
                plugin.markBuilt(g.id(), false);
                queueBuild(g);
            }
        }
        pump();
    }

    public void shutdown() {
        for (List<Game> l : games.values()) for (Game g : l) g.shutdown();
        inGame.clear();
    }

    // ---------- pemain ----------
    public Game of(Player p) { return inGame.get(p.getUniqueId()); }
    public void forget(UUID u) { inGame.remove(u); }
    public List<Game> list(String key) { return games.get(key); }
    public Set<String> keys() { return games.keySet(); }

    public Game gameAt(Location loc) {
        if (world == null || loc.getWorld() != world) return null;
        for (List<Game> l : games.values())
            for (Game g : l)
                if (Math.abs(loc.getX() - g.cx) < 140 && Math.abs(loc.getZ() - g.cz) < 140) return g;
        return null;
    }

    public void join(Player p, String key) {
        if (world == null) { Msg.send(p, "&cPlugin masih memuat world, coba beberapa detik lagi."); return; }
        if (inGame.containsKey(p.getUniqueId())) { Msg.send(p, "&cKamu sudah ada di dalam game. Pakai &e/zm leave&c."); return; }
        List<Game> l = games.get(key);
        if (l == null) { Msg.send(p, "&cGame tidak ditemukan atau dimatikan."); return; }
        if (key.equals("practice")) { openKitMenu(p); return; }
        Game best = null;
        for (Game g : l) {
            if (!g.joinable()) continue;
            if (best == null || g.players.size() > best.players.size()) best = g;
        }
        if (best == null) {
            boolean preparing = false;
            for (Game g : l) if (g.state == Game.State.RESETTING) preparing = true;
            Msg.send(p, preparing ? "&eArena &f" + l.get(0).name + " &esedang disiapkan, tunggu sebentar."
                    : "&cSemua arena &f" + l.get(0).name + " &csedang berjalan atau penuh.");
            return;
        }
        if (best.join(p)) inGame.put(p.getUniqueId(), best);
    }

    public boolean leave(Player p) {
        Game g = inGame.remove(p.getUniqueId());
        if (g == null) return false;
        g.leave(p);
        return true;
    }

    public void setOpen(String key, boolean open) {
        List<Game> l = games.get(key);
        if (l != null) for (Game g : l) g.open = open;
    }

    // ---------- bot latihan ----------
    public int botLevel(UUID u) { return botPref.getOrDefault(u, 0); }

    public void setBot(Player p, int lvl) {
        botPref.put(p.getUniqueId(), lvl);
        if (of(p) instanceof PracticeGame pg) pg.setBotLevel(p, lvl);
    }

    public int cycleBot(Player p) {
        int lvl = (botLevel(p.getUniqueId()) + 1) % PracticeGame.LEVELS.length;
        setBot(p, lvl);
        return lvl;
    }

    // ---------- menu ----------
    private static final Map<String, String> CATEGORY = Map.of(
            "sumo", "Battle", "tnttag", "Party", "crumble", "Lari", "colorrush", "Refleks",
            "pillars", "Survival", "tinyhunt", "Petak Umpet", "duel", "Duel 1v1", "practice", "PvP Bebas");

    private static List<String> wrap(String text, int width) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String w : text.split(" ")) {
            if (cur.length() > 0 && cur.length() + w.length() + 1 > width) {
                out.add(cur.toString());
                cur.setLength(0);
            }
            if (cur.length() > 0) cur.append(' ');
            cur.append(w);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    private ItemStack named(ItemStack it, String name, List<String> lore, boolean glow) {
        ItemMeta m = it.getItemMeta();
        m.displayName(Msg.c(name));
        List<Component> l = new ArrayList<>();
        for (String s : lore) l.add(Msg.c(s));
        m.lore(l);
        m.addItemFlags(ItemFlag.values());
        if (glow) m.setEnchantmentGlintOverride(true);
        it.setItemMeta(m);
        return it;
    }

    private ItemStack pane(Material m) {
        return named(new ItemStack(m), " ", List.of(), false);
    }

    private void frame(Inventory inv, int rows) {
        ItemStack dark = pane(Material.BLACK_STAINED_GLASS_PANE);
        ItemStack cyan = pane(Material.CYAN_STAINED_GLASS_PANE);
        ItemStack grey = pane(Material.GRAY_STAINED_GLASS_PANE);
        for (int i = 0; i < rows * 9; i++) {
            int r = i / 9, c = i % 9;
            boolean edge = r == 0 || r == rows - 1 || c == 0 || c == 8;
            inv.setItem(i, edge ? ((r == 0 || r == rows - 1) && c % 2 == 0 ? cyan : dark) : grey);
        }
    }

    private int totalPlayers() {
        int t = 0;
        for (List<Game> l : games.values()) for (Game g : l) t += g.players.size();
        return t;
    }

    public void openMenu(Player p) {
        MenuHolder h = new MenuHolder();
        Inventory inv = Bukkit.createInventory(h, 54, Msg.c("&b&lZentra &3&lMinigames"));
        h.inv = inv;
        frame(inv, 6);

        inv.setItem(4, named(new ItemStack(Material.NETHER_STAR), "&b&lZENTRA MINIGAMES", List.of(
                "&7Pilih game lalu klik untuk bergabung.",
                " ",
                "&8\u00bb &fSedang bermain &a" + totalPlayers() + " &fpemain",
                "&8\u00bb &7Klik kanan pada game = lihat aturan"), true));
        h.keys.put(4, "_info");

        int[] slots = {19, 20, 21, 22, 23, 24, 25};
        int idx = 0;
        for (Map.Entry<String, List<Game>> en : games.entrySet()) {
            if (en.getKey().equals("practice")) continue;
            if (idx >= slots.length) break;
            List<Game> list = en.getValue();
            Game f = list.get(0);
            int total = 0, openCnt = 0;
            boolean cd = false, resetting = false;
            for (Game g : list) {
                total += g.players.size();
                if (g.joinable()) {
                    openCnt++;
                    if (g.state == Game.State.COUNTDOWN) cd = true;
                }
                if (g.state == Game.State.RESETTING) resetting = true;
            }
            String status = openCnt > 0
                    ? (cd ? "&eHitung mundur" : total > 0 ? "&aMenunggu pemain" : "&aSiap dimainkan")
                    : (resetting ? "&7Menyiapkan arena" : "&cSedang berjalan");
            List<String> lore = new ArrayList<>();
            lore.add("&8" + CATEGORY.getOrDefault(en.getKey(), "Minigame") + " \u2022 " + f.min + "-" + f.max + " pemain");
            lore.add(" ");
            for (String w : wrap(f.rules.get(0), 34)) lore.add("&7" + w);
            lore.add(" ");
            lore.add("&8\u00bb &fPemain &a" + total);
            lore.add("&8\u00bb &fStatus " + status);
            lore.add("&8\u00bb &fArena &b" + openCnt + "&7/&b" + list.size() + " &7terbuka");
            lore.add(" ");
            lore.add(openCnt > 0 ? "&a\u25b6 Klik kiri &7untuk bergabung" : "&c\u2716 Belum bisa bergabung");
            lore.add("&e\u25b6 Klik kanan &7untuk lihat aturan");
            inv.setItem(slots[idx], named(new ItemStack(f.icon), "&b&l" + f.name, lore, openCnt > 0));
            h.keys.put(slots[idx], en.getKey());
            idx++;
        }

        List<Game> pl = games.get("practice");
        if (pl != null) {
            int pt = 0, pm = 0;
            for (Game g : pl) { pt += g.players.size(); pm += g.max; }
            List<String> lore = new ArrayList<>();
            lore.add("&8PvP Bebas \u2022 tanpa ronde");
            lore.add(" ");
            for (String w : wrap(pl.get(0).rules.get(0), 34)) lore.add("&7" + w);
            lore.add(" ");
            lore.add("&fKit tersedia:");
            for (Kit k : Kit.values()) lore.add("&8\u00bb " + k.colored());
            lore.add(" ");
            lore.add("&8\u00bb &fSedang berlatih &a" + pt + "&7/&f" + pm);
            lore.add(" ");
            lore.add("&a\u25b6 Klik kiri &7untuk memilih kit");
            lore.add("&e\u25b6 Klik kanan &7untuk lihat aturan");
            inv.setItem(40, named(new ItemStack(Material.END_CRYSTAL), "&c&lPractice PvP", lore, true));
            h.keys.put(40, "practice");
        }

        inv.setItem(38, named(new ItemStack(Material.BOOK), "&e&lCara Bermain", List.of(
                "&7Klik game untuk masuk ke arena",
                "&7yang paling ramai.",
                " ",
                "&7Di ruang tunggu, pakai item hotbar:",
                "&8\u00bb &fAturan Main, Panggil Teman, Vote Mulai"), false));
        h.keys.put(38, "_info");

        if (inGame.containsKey(p.getUniqueId())) {
            Game cur = inGame.get(p.getUniqueId());
            inv.setItem(49, named(new ItemStack(Material.BARRIER), "&c&lKeluar dari game", List.of(
                    "&7Sedang di: &f" + cur.name, "&7Kembali ke tempat semula"), false));
            h.keys.put(49, "_leave");
        }
        p.openInventory(inv);
        p.playSound(p.getLocation(), Sound.BLOCK_ENDER_CHEST_OPEN, 0.6f, 1.3f);
    }

    public void openKitMenu(Player p) {
        if (world == null) { Msg.send(p, "&cPlugin masih memuat world, coba beberapa detik lagi."); return; }
        List<Game> pl = games.get("practice");
        if (pl == null) { Msg.send(p, "&cPractice PvP tidak aktif."); return; }
        MenuHolder h = new MenuHolder();
        Inventory inv = Bukkit.createInventory(h, 27, Msg.c("&c&lPractice PvP &8\u00bb &7Pilih Kit"));
        h.inv = inv;
        frame(inv, 3);
        int pt = 0, pm = 0;
        for (Game g : pl) { pt += g.players.size(); pm += g.max; }
        inv.setItem(4, named(new ItemStack(Material.END_CRYSTAL), "&c&lPractice PvP", List.of(
                "&7Arena datar luas, respawn instan.",
                " ",
                "&8\u00bb &fSedang berlatih &a" + pt + "&7/&f" + pm,
                "&8\u00bb &7Pilih kit di bawah untuk masuk"), true));
        h.keys.put(4, "_info");
        boolean in = of(p) instanceof PracticeGame;
        int[] slots = {10, 12, 14, 16};
        Kit[] ks = Kit.values();
        for (int i = 0; i < ks.length && i < slots.length; i++) {
            List<String> lore = new ArrayList<>(ks[i].lore);
            lore.add(" ");
            lore.add(in ? "&e\u25b6 Klik untuk ganti kit &8(respawn)" : "&a\u25b6 Klik untuk masuk arena");
            inv.setItem(slots[i], named(ks[i].icon(), ks[i].color + "&l" + ks[i].display, lore, true));
            h.keys.put(slots[i], "kit:" + ks[i].name());
        }
        int bl = botLevel(p.getUniqueId());
        inv.setItem(22, named(new ItemStack(Material.ZOMBIE_HEAD), "&a&lLawan Bot: " + PracticeGame.LEVEL_COLORS[bl] + "&l" + PracticeGame.LEVELS[bl],
                List.of("&7Bot (Husk) akan mengejar dan menyerangmu.",
                        "&7Tingkat: &aMudah &8/ &eSedang &8/ &cSulit",
                        " ",
                        "&e\u25b6 Klik untuk ganti tingkat"), bl > 0));
        h.keys.put(22, "_bot");
        inv.setItem(20, named(new ItemStack(Material.ARROW), "&7\u00ab Kembali", List.of("&7Ke menu utama"), false));
        h.keys.put(20, "_back");
        p.openInventory(inv);
        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.8f, 1.2f);
    }

    /** Pemain memilih kit: masuk ke Practice atau ganti kit kalau sudah di dalam. */
    public void pickKit(Player p, Kit kit) {
        Game cur = of(p);
        if (cur instanceof PracticeGame pg) { pg.changeKit(p, kit); return; }
        if (cur != null) { Msg.send(p, "&cKamu sudah ada di dalam game. Pakai &e/zm leave&c."); return; }
        List<Game> l = games.get("practice");
        if (world == null || l == null) { Msg.send(p, "&cPractice PvP belum siap."); return; }
        PracticeGame target = null;
        for (Game g : l) {
            if (g instanceof PracticeGame pg && g.joinable()) { target = pg; break; }
        }
        if (target == null) { Msg.send(p, "&eArena Practice sedang disiapkan atau penuh, coba lagi sebentar."); return; }
        if (target.joinWith(p, kit)) inGame.put(p.getUniqueId(), target);
    }

    public void showRules(Player p, String key) {
        List<Game> l = games.get(key);
        if (l != null) l.get(0).showRules(p);
    }
}
