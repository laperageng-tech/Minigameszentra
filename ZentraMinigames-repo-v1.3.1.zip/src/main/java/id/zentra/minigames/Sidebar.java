package id.zentra.minigames;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.ArrayList;
import java.util.List;

/** Scoreboard samping per pemain (tanpa kedip, memakai team prefix). */
public final class Sidebar {
    private static final int MAX = 15;
    private final Scoreboard sb;
    private final Objective obj;
    private final List<Team> teams = new ArrayList<>();
    private final List<String> entries = new ArrayList<>();
    private int shown = 0;

    public Sidebar() {
        sb = Bukkit.getScoreboardManager().getNewScoreboard();
        obj = sb.registerNewObjective("zm", Criteria.DUMMY, Component.text(""));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        ChatColor[] cc = ChatColor.values();
        for (int i = 0; i < MAX; i++) {
            String e = cc[i].toString() + ChatColor.RESET;
            Team t = sb.registerNewTeam("l" + i);
            t.addEntry(e);
            teams.add(t);
            entries.add(e);
        }
    }

    public void show(Player p) {
        p.setScoreboard(sb);
    }

    public void set(String title, List<String> lines) {
        obj.displayName(Msg.c(title));
        int n = Math.min(MAX, lines.size());
        for (int i = 0; i < n; i++) {
            teams.get(i).prefix(Msg.c(lines.get(i)));
            obj.getScore(entries.get(i)).setScore(n - i);
        }
        for (int i = n; i < shown; i++) sb.resetScores(entries.get(i));
        shown = n;
    }
}
