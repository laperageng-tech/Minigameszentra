package id.zentra.minigames;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

import java.util.List;

/** Kit untuk Practice PvP. */
public enum Kit {
    CRYSTAL("Crystal PvP", "&d", Material.END_CRYSTAL, List.of(
            "&7Armor Netherite &8(Protection IV)",
            "&7Pedang Netherite &8(Sharpness V)",
            "&7End Crystal &8x128 &7+ Obsidian &8x128",
            "&7Totem &8x4 &7+ Golden Apple + Ender Pearl")),
    MACE("Mace", "&6", Material.MACE, List.of(
            "&7Armor Netherite &8(Protection IV)",
            "&7Mace &8(Density V) &7+ Tombak Netherite &8(Lunge)",
            "&7Wind Charge &8x64 &7untuk lompat smash",
            "&7Kapak anti-tameng + Golden Apple")),
    SWORD("Sword", "&b", Material.DIAMOND_SWORD, List.of(
            "&7Armor Diamond &8(Protection IV)",
            "&7Pedang Diamond &8(Sharpness III)",
            "&7Shield + Golden Apple &8x8",
            "&7Ender Pearl &8x4")),
    NODEBUFF("NoDebuff", "&c", Material.SPLASH_POTION, List.of(
            "&7Armor Diamond &8(Protection IV)",
            "&7Pedang Diamond &8(Sharpness II)",
            "&7Splash Instant Health II &8(banyak)",
            "&7Speed Potion + Ender Pearl &8x16"));

    public final String display, color;
    public final Material material;
    public final List<String> lore;

    Kit(String display, String color, Material material, List<String> lore) {
        this.display = display;
        this.color = color;
        this.material = material;
        this.lore = lore;
    }

    public String colored() { return color + display; }

    public static Kit parse(String s) {
        if (s == null) return null;
        String k = s.toLowerCase().replace("_", "").replace("-", "").replace(" ", "");
        return switch (k) {
            case "crystal", "crystalpvp", "cpvp" -> CRYSTAL;
            case "mace" -> MACE;
            case "sword", "sw" -> SWORD;
            case "nodebuff", "nd", "debuff" -> NODEBUFF;
            default -> null;
        };
    }

    /** Ikon untuk menu. */
    public ItemStack icon() {
        ItemStack it = new ItemStack(material);
        if (this == NODEBUFF) it.setItemMeta(potionMeta(it, PotionType.STRONG_HEALING));
        return it;
    }

    private static PotionMeta potionMeta(ItemStack it, PotionType type) {
        PotionMeta pm = (PotionMeta) it.getItemMeta();
        pm.setBasePotionType(type);
        return pm;
    }

    private static ItemStack potion(Material m, PotionType type, int amt) {
        ItemStack it = new ItemStack(m, amt);
        it.setItemMeta(potionMeta(it, type));
        return it;
    }

    private static ItemStack gear(Material m, Enchantment e, int lvl) {
        ItemStack it = new ItemStack(m);
        ItemMeta mm = it.getItemMeta();
        mm.setUnbreakable(true);
        it.setItemMeta(mm);
        if (e != null) it.addUnsafeEnchantment(e, lvl);
        return it;
    }

    /** Tombak (1.21.11+). Dicari lewat nama supaya tetap aman kalau API-nya belum punya. */
    private static ItemStack spear() {
        Material m = Material.matchMaterial("NETHERITE_SPEAR");
        if (m == null) return gear(Material.DIAMOND_SWORD, Enchantment.SHARPNESS, 3);
        ItemStack it = gear(m, null, 0);
        Enchantment lunge = Registry.ENCHANTMENT.get(NamespacedKey.minecraft("lunge"));
        if (lunge != null) it.addUnsafeEnchantment(lunge, 3);
        return it;
    }

    private static void armor(PlayerInventory inv, String tier, int prot) {
        inv.setHelmet(gear(Material.valueOf(tier + "_HELMET"), Enchantment.PROTECTION, prot));
        inv.setChestplate(gear(Material.valueOf(tier + "_CHESTPLATE"), Enchantment.PROTECTION, prot));
        inv.setLeggings(gear(Material.valueOf(tier + "_LEGGINGS"), Enchantment.PROTECTION, prot));
        inv.setBoots(gear(Material.valueOf(tier + "_BOOTS"), Enchantment.PROTECTION, prot));
    }

    /** Hotbar slot 7 dan 8 dicadangkan untuk item "Ganti Kit" dan "Keluar". */
    public void give(Player p) {
        PlayerInventory inv = p.getInventory();
        inv.clear();
        switch (this) {
            case CRYSTAL -> {
                armor(inv, "NETHERITE", 4);
                inv.setItem(0, gear(Material.NETHERITE_SWORD, Enchantment.SHARPNESS, 5));
                inv.setItem(1, new ItemStack(Material.END_CRYSTAL, 64));
                inv.setItem(2, new ItemStack(Material.OBSIDIAN, 64));
                inv.setItem(3, new ItemStack(Material.GOLDEN_APPLE, 16));
                inv.setItem(4, new ItemStack(Material.ENDER_PEARL, 16));
                inv.setItem(5, new ItemStack(Material.END_CRYSTAL, 64));
                inv.setItem(6, new ItemStack(Material.OBSIDIAN, 64));
                inv.setItemInOffHand(new ItemStack(Material.TOTEM_OF_UNDYING));
                for (int i = 9; i < 12; i++) inv.setItem(i, new ItemStack(Material.TOTEM_OF_UNDYING));
            }
            case MACE -> {
                armor(inv, "NETHERITE", 4);
                inv.setItem(0, gear(Material.MACE, Enchantment.DENSITY, 5));
                inv.setItem(1, spear());
                inv.setItem(2, new ItemStack(Material.WIND_CHARGE, 64));
                inv.setItem(3, gear(Material.DIAMOND_AXE, Enchantment.SHARPNESS, 3));
                inv.setItem(4, new ItemStack(Material.GOLDEN_APPLE, 16));
                inv.setItem(5, new ItemStack(Material.ENDER_PEARL, 8));
                inv.setItemInOffHand(new ItemStack(Material.SHIELD));
            }
            case NODEBUFF -> {
                armor(inv, "DIAMOND", 4);
                inv.setItem(0, gear(Material.DIAMOND_SWORD, Enchantment.SHARPNESS, 2));
                inv.setItem(1, new ItemStack(Material.ENDER_PEARL, 16));
                inv.setItem(2, potion(Material.POTION, PotionType.STRONG_SWIFTNESS, 1));
                for (int i = 3; i <= 6; i++) inv.setItem(i, potion(Material.SPLASH_POTION, PotionType.STRONG_HEALING, 1));
                inv.setItem(9, potion(Material.POTION, PotionType.STRONG_SWIFTNESS, 1));
                for (int i = 10; i < 36; i++) inv.setItem(i, potion(Material.SPLASH_POTION, PotionType.STRONG_HEALING, 1));
            }
            default -> {
                armor(inv, "DIAMOND", 4);
                inv.setItem(0, gear(Material.DIAMOND_SWORD, Enchantment.SHARPNESS, 3));
                inv.setItem(1, new ItemStack(Material.GOLDEN_APPLE, 8));
                inv.setItem(2, new ItemStack(Material.ENDER_PEARL, 4));
                inv.setItemInOffHand(new ItemStack(Material.SHIELD));
            }
        }
    }
}
