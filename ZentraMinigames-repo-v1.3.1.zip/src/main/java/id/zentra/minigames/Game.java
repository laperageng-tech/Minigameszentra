package id.zentra.minigames;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.function.Predicate;

/** Kerangka dasar semua minigame: antrean, hitung mundur, eliminasi, pemenang, reset arena. */
public abstract class Game {
    public enum State { WAITING, COUNTDOWN, RUNNING, ENDING, RESETTING }

    static final int LOBBY_UP = 50;
    private static final String[] DOTS = {"", ".", "..", "..."};
    private static final String[] SPIN = {"&b\u25aa&3\u25aa\u25aa", "&3\u25aa&b\u25aa&3\u25aa", "&3\u25aa\u25aa&b\u25aa", "&3\u25aa&b\u25aa&3\u25aa"};
    private static final String[] TIPS = {
            "Klik &fPanggil Teman &7untuk mengajak pemain lain",
            "Klik &fVote Mulai &7supaya game mulai lebih cepat",
            "Klik &fAturan Main &7untuk membaca cara bermain",
            "Makin ramai makin seru, ajak temanmu!",
            "Ketik &f/zm leave &7kapan saja untuk keluar"};

    private record Saved(ItemStack[] inv, Location loc, GameMode gm, double hp, int food, float sat,
                         float exp, int lvl, List<PotionEffect> fx, boolean fly) {}

    protected final ZentraMinigames plugin;
    protected final World world;
    public final String key, name;
    public final Material icon;
    public final int instance, cx, by, cz;
    public final List<String> rules;
    public int min, max;
    public State state = State.RESETTING;
    public boolean open = true;

    protected boolean pvp, envDamage, fallDamage, canBuild, lockInv = true;
    /** true = tanpa ronde (Practice): pemain bebas masuk/keluar kapan saja. */
    protected boolean continuous;
    protected int voidY;
    protected int countdown, cdFull, runSecs;

    public final Set<UUID> players = new LinkedHashSet<>();
    public final Set<UUID> alive = new LinkedHashSet<>();
    protected final Map<UUID, UUID> lastHit = new HashMap<>();
    private final Map<UUID, Saved> saved = new HashMap<>();
    protected final Random rnd = new Random();
    protected final BossBar bar;
    protected long ticks;
    private BukkitTask task;
    private final Map<UUID, Sidebar> boards = new HashMap<>();
    private final Map<UUID, Scoreboard> prevBoards = new HashMap<>();
    private final Set<UUID> votes = new HashSet<>();
    private final Map<UUID, Long> inviteCd = new HashMap<>();
    private TextDisplay holo;

    protected Game(ZentraMinigames plugin, String key, String name, Material icon, int instance,
                   int cx, int by, int cz, int min, int max, List<String> rules) {
        this.plugin = plugin;
        this.world = plugin.manager().world();
        this.key = key;
        this.name = name;
        this.icon = icon;
        this.instance = instance;
        this.cx = cx;
        this.by = by;
        this.cz = cz;
        this.min = min;
        this.max = max;
        this.rules = rules;
        this.voidY = by - 15;
        this.bar = Bukkit.createBossBar("", BarColor.BLUE, BarStyle.SOLID);
    }

    // ---------- hook yang dioverride tiap game ----------
    protected abstract void buildArena(Blueprint b);
    protected abstract void onStart();
    protected void onSecond() {}
    protected void onFast() {}
    protected void onEnd() {}
    protected void onReset() {}
    protected void onLeave(Player p, boolean wasAlive) {}
    protected void onHit(EntityDamageEvent e, Player victim, Player damager) { e.setCancelled(true); }
    protected String barText() { return "&b" + name + " &8| &fHidup: &a" + alive.size(); }
    public void onInteract(PlayerInteractEvent e) {}
    public boolean allowBreak(Block b, Player p) { return false; }
    public boolean allowPlace(Block b, Player p) { return false; }
    public void onExplode(EntityExplodeEvent e) { e.blockList().clear(); }

    // ---------- info ----------
    public String id() { return key + "-" + instance; }
    public boolean canBuild() { return canBuild; }
    public boolean lockInv() { return lockInv; }
    public boolean joinable() {
        return open && (state == State.WAITING || state == State.COUNTDOWN) && players.size() < max;
    }
    protected boolean hasLobby() { return true; }
    public Location lobby() { return new Location(world, cx + 0.5, by + LOBBY_UP + 1, cz + 0.5); }
    public Location specSpawn() { return new Location(world, cx + 0.5, by + 30, cz + 0.5); }

    // ---------- siklus hidup ----------
    public void activate() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::loop, 20L, 5L);
    }

    public void shutdown() {
        if (task != null) task.cancel();
        for (UUID u : new ArrayList<>(players)) {
            Player p = Bukkit.getPlayer(u);
            if (p != null) restore(p);
        }
        players.clear();
        alive.clear();
        bar.removeAll();
        if (holo != null && holo.isValid()) holo.remove();
    }

    public void build(Runnable done) {
        state = State.RESETTING;
        Blueprint b = new Blueprint();
        if (hasLobby()) buildLobby(b);
        buildArena(b);
        b.build(plugin, world, () -> {
            ensureHolo();
            if (done != null) done.run();
        });
    }

    private void buildLobby(Blueprint b) {
        int y = by + LOBBY_UP;
        b.cone(cx, y - 1, cz, 9, 9, Material.DEEPSLATE);
        b.disc(cx, y, cz, 8, Material.WHITE_CONCRETE);
        b.ring(cx, y, cz, 5, 6, Material.LIGHT_BLUE_CONCRETE);
        b.disc(cx, y, cz, 2, Material.SEA_LANTERN);
        for (int h = 1; h <= 3; h++) b.ring(cx, y + h, cz, 7, 8, Material.LIGHT_BLUE_STAINED_GLASS);
        for (int[] o : new int[][]{{7, 0}, {-7, 0}, {0, 7}, {0, -7}}) {
            b.fill(cx + o[0], y + 1, cz + o[1], cx + o[0], y + 4, cz + o[1], Material.QUARTZ_PILLAR);
            b.set(cx + o[0], y + 5, cz + o[1], Material.SEA_LANTERN);
        }
    }

    private void loop() {
        ticks++;
        if (state == State.RESETTING) return;
        if (ticks % 4 == 0) second();
        if (state == State.WAITING || state == State.COUNTDOWN) lobbyAnim();
        if (state == State.RUNNING) onFast();
        for (UUID u : new ArrayList<>(players)) {
            Player p = Bukkit.getPlayer(u);
            if (p == null) continue;
            double y = p.getLocation().getY();
            if (state == State.WAITING || state == State.COUNTDOWN) {
                if (!continuous && y < by + LOBBY_UP - 8) p.teleport(lobby());
            } else if (y < voidY) {
                if (state == State.RUNNING && alive.contains(u)) onOut(p, lastHitter(p), "jatuh ke void");
                else p.teleport(specSpawn());
            }
        }
    }

    // ---------- tampilan ruang tunggu ----------
    private int voteNeed() { return Math.max(1, (int) Math.ceil(players.size() / 2.0)); }

    /** Animasi 4x per detik: actionbar berganti-ganti (status / tips) dan partikel lobby. */
    private void lobbyAnim() {
        if (players.isEmpty()) return;
        long f = ticks;
        int n = players.size();
        boolean showTip = (f / 16) % 3 == 2;
        for (Player p : online()) {
            if (state == State.COUNTDOWN) {
                Msg.bar(p, "&a\u2714 &7Pemain cukup! Mulai dalam &e" + countdown + "s &8| &7Vote: &f" + votes.size() + "&7/&f" + voteNeed());
            } else if (showTip) {
                Msg.bar(p, "&e\u00bb &7" + TIPS[(int) ((f / 48) % TIPS.length)]);
            } else if (n == 1 && min > 1) {
                Msg.bar(p, SPIN[(int) (f % 4)] + " &7Belum ada lawan, ajak teman lewat &bPanggil Teman &8" + DOTS[(int) (f % 4)]);
            } else {
                Msg.bar(p, SPIN[(int) (f % 4)] + " &7Menunggu pemain &f" + n + "&7/&f" + min + " &8" + DOTS[(int) (f % 4)]);
            }
        }
        if (!hasLobby()) return;
        Location c = lobby();
        double a = f * 0.4;
        for (int k = 0; k < 3; k++) {
            double ang = a + k * 2.094;
            world.spawnParticle(Particle.END_ROD, c.getX() + Math.cos(ang) * 6.5, c.getY() + 0.4 + Math.sin(f * 0.3 + k) * 0.4,
                    c.getZ() + Math.sin(ang) * 6.5, 1, 0, 0, 0, 0);
        }
    }

    protected String sidebarTitle() {
        return ((ticks / 4) % 2 == 0 ? "&b&l" : "&3&l") + name.toUpperCase();
    }

    protected List<String> sideExtra() { return List.of(); }

    protected List<String> sidebar(Player p) {
        List<String> l = new ArrayList<>();
        l.add("&8" + id());
        l.add(" ");
        if (state == State.WAITING || state == State.COUNTDOWN) {
            l.add("&fPemain &8\u00bb &a" + players.size() + "&7/&f" + max);
            l.add("&fMinimal &8\u00bb &e" + min);
            l.add(" ");
            l.add(state == State.COUNTDOWN ? "&fMulai &8\u00bb &e" + countdown + "s" : "&fStatus &8\u00bb &7menunggu");
            l.add("&fVote &8\u00bb &a" + votes.size() + "&7/&f" + voteNeed());
        } else if (state == State.RUNNING) {
            l.add("&fHidup &8\u00bb &a" + alive.size() + "&7/&f" + players.size());
            l.add("&fWaktu &8\u00bb &e" + fmtTime(runSecs));
            List<String> ex = sideExtra();
            if (!ex.isEmpty()) {
                l.add(" ");
                l.addAll(ex);
            }
        } else {
            l.add("&6Game selesai!");
        }
        l.add(" ");
        l.add("&b/zm leave &7= keluar");
        return l;
    }

    protected static String fmtTime(int secs) {
        return String.format("%d:%02d", secs / 60, secs % 60);
    }

    private void updateBoards() {
        for (Player p : online()) {
            Sidebar sb = boards.get(p.getUniqueId());
            if (sb != null) sb.set(sidebarTitle(), sidebar(p));
        }
    }

    protected void attachBoard(Player p) {
        UUID u = p.getUniqueId();
        prevBoards.put(u, p.getScoreboard());
        Sidebar sb = new Sidebar();
        boards.put(u, sb);
        sb.show(p);
    }

    private void detachBoard(Player p) {
        UUID u = p.getUniqueId();
        boards.remove(u);
        Scoreboard prev = prevBoards.remove(u);
        p.setScoreboard(prev != null ? prev : Bukkit.getScoreboardManager().getMainScoreboard());
    }

    // ---------- hologram ----------
    protected Location holoLoc() { return hasLobby() ? lobby().add(0, 3.6, 0) : null; }

    protected Component holoText() {
        String st = switch (state) {
            case WAITING -> "&7Menunggu pemain...";
            case COUNTDOWN -> "&eMulai dalam &f" + countdown + "s";
            case RUNNING -> "&cSedang berjalan";
            default -> "&7Menyiapkan arena...";
        };
        return Msg.c("&b&l" + name.toUpperCase() + "\n&8&m               \n" + st + "\n&a" + players.size() + "&7/&f" + max + " &8pemain");
    }

    protected void ensureHolo() {
        if (holo != null && holo.isValid()) return;
        Location l = holoLoc();
        if (l == null) return;
        l.getChunk().load();
        holo = world.spawn(l, TextDisplay.class, d -> {
            d.setBillboard(Display.Billboard.CENTER);
            d.setPersistent(false);
            d.setAlignment(TextDisplay.TextAlignment.CENTER);
            d.setBackgroundColor(Color.fromARGB(110, 0, 0, 0));
            d.text(holoText());
        });
    }

    private void updateHolo() {
        if (players.isEmpty() && (holo == null || !holo.isValid())) return;
        ensureHolo();
        if (holo != null && holo.isValid()) holo.text(holoText());
    }

    // ---------- hitung mundur ----------
    private void second() {
        if (continuous && state == State.WAITING) {
            state = State.RUNNING;
            runSecs = 0;
        }
        updateBoards();
        updateHolo();
        if (state == State.WAITING) {
            int n = players.size();
            if (n >= min) {
                state = State.COUNTDOWN;
                cdFull = Math.max(5, plugin.getConfig().getInt("countdown", 20));
                countdown = cdFull;
                for (Player p : online()) {
                    Msg.title(p, "&a&lSIAP-SIAP!", "&7Pemain sudah cukup, game segera mulai", 0, 30, 10);
                    p.playSound(p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1f, 1.3f);
                }
                checkVotes();
            } else if (n > 0) {
                int need = min - n;
                setBar("&b&lMENUNGGU PEMAIN &8\u00bb &f" + n + "&7/&f" + min + " &8(butuh &e" + need + " &8lagi)",
                        n / (double) min, n * 2 < min ? BarColor.RED : BarColor.YELLOW);
            }
        } else if (state == State.COUNTDOWN) {
            if (players.size() < min) {
                state = State.WAITING;
                bc("&cPemain kurang, hitung mundur dibatalkan.");
                sound(Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 0.6f);
                return;
            }
            checkVotes();
            if (players.size() >= max && countdown > 5) countdown = 5;
            if (countdown <= 0) {
                begin();
                return;
            }
            setBar("&a&lMULAI DALAM &f" + countdown + "s &8(" + players.size() + "/" + max + ")",
                    countdown / (double) cdFull, countdown > 10 ? BarColor.GREEN : countdown > 5 ? BarColor.YELLOW : BarColor.RED);
            if (countdown == cdFull || countdown == 15 || countdown == 10) {
                bc("&7Game dimulai dalam &e" + countdown + " &7detik");
            }
            if (countdown <= 5) {
                String col = countdown >= 4 ? "&e" : countdown == 3 ? "&6" : countdown == 2 ? "&c" : "&4";
                for (Player p : online()) {
                    Msg.title(p, col + "&l" + countdown, "&7Bersiaplah!", 0, 20, 5);
                    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 0.8f + (5 - countdown) * 0.15f);
                }
            }
            countdown--;
        } else if (state == State.RUNNING) {
            runSecs++;
            setBar(barText(), 1, BarColor.BLUE);
            onSecond();
        }
    }

    public void forceStart() {
        if ((state == State.WAITING || state == State.COUNTDOWN) && !players.isEmpty()) begin();
    }

    private void begin() {
        state = State.RUNNING;
        runSecs = 0;
        votes.clear();
        alive.clear();
        alive.addAll(players);
        lastHit.clear();
        for (Player p : online()) {
            resetPlayer(p, canBuild ? GameMode.SURVIVAL : GameMode.ADVENTURE);
            Msg.title(p, "&b&l" + name.toUpperCase(), "&7" + rules.get(0), 5, 50, 10);
            p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.6f, 1.2f);
        }
        onStart();
    }

    // ---------- item & aksi ruang tunggu ----------
    public void lobbyAction(Player p, String id) {
        switch (id) {
            case "leave" -> {
                if (plugin.manager().leave(p)) Msg.send(p, "&7Kamu keluar dari game.");
            }
            case "rules" -> showRules(p);
            case "invite" -> invite(p);
            case "vote" -> toggleVote(p);
            default -> { }
        }
    }

    public void showRules(Player p) {
        Msg.line(p);
        p.sendMessage(Msg.c(" &b&l" + name.toUpperCase() + " &8- &7Cara Bermain"));
        int i = 1;
        for (String r : rules) p.sendMessage(Msg.c(" &b" + (i++) + ". &f" + r));
        Msg.line(p);
        p.playSound(p.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 1f, 1f);
    }

    private void toggleVote(Player p) {
        if (state != State.WAITING && state != State.COUNTDOWN) return;
        UUID u = p.getUniqueId();
        if (votes.remove(u)) {
            Msg.send(p, "&7Vote mulai cepat dibatalkan.");
        } else {
            votes.add(u);
            bc("&a" + p.getName() + " &7vote mulai cepat &8(" + votes.size() + "/" + voteNeed() + ")");
        }
        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 1f, 1.4f);
        checkVotes();
    }

    private void checkVotes() {
        if (state == State.COUNTDOWN && votes.size() >= voteNeed() && countdown > 10) {
            countdown = 10;
            bc("&aMayoritas pemain setuju, hitung mundur dipercepat!");
        }
    }

    private void invite(Player p) {
        if (!joinable()) return;
        long now = System.currentTimeMillis();
        Long last = inviteCd.get(p.getUniqueId());
        if (last != null && now - last < 30000) {
            Msg.send(p, "&cTunggu &f" + ((30000 - (now - last)) / 1000 + 1) + " detik &clagi sebelum mengajak lagi.");
            return;
        }
        inviteCd.put(p.getUniqueId(), now);
        Component join = Msg.c("&a&l[GABUNG]")
                .clickEvent(ClickEvent.runCommand("/zm join " + key))
                .hoverEvent(HoverEvent.showText(Msg.c("&7Klik untuk bergabung ke &b" + name)));
        Component msg = Msg.c(Msg.PREFIX + "&e" + p.getName() + " &7mengajak main &b" + name + " &8(" + players.size() + "/" + max + ") ").append(join);
        int sent = 0;
        for (Player o : Bukkit.getOnlinePlayers()) {
            if (o.equals(p) || plugin.manager().of(o) != null) continue;
            o.sendMessage(msg);
            o.playSound(o.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
            sent++;
        }
        Msg.send(p, "&aUndangan terkirim ke &f" + sent + " &apemain.");
        p.playSound(p.getLocation(), Sound.BLOCK_BELL_USE, 1f, 1.2f);
    }

    private void giveLobbyItems(Player p) {
        p.getInventory().setItem(0, plugin.lobbyItem(Material.BOOK, "&e&lAturan Main &7(klik kanan)", "rules", "&7Baca cara bermain"));
        p.getInventory().setItem(1, plugin.lobbyItem(Material.BELL, "&b&lPanggil Teman &7(klik kanan)", "invite", "&7Ajak pemain lain lewat chat"));
        p.getInventory().setItem(4, plugin.lobbyItem(Material.CLOCK, "&a&lVote Mulai Cepat &7(klik kanan)", "vote", "&7Mayoritas setuju = hitung mundur 10 detik"));
        p.getInventory().setItem(8, plugin.leaveItem());
    }

    // ---------- pemain masuk / keluar ----------
    protected void snapshot(Player p) {
        ItemStack[] copy = p.getInventory().getContents().clone();
        for (int i = 0; i < copy.length; i++) if (copy[i] != null) copy[i] = copy[i].clone();
        saved.put(p.getUniqueId(), new Saved(copy, p.getLocation().clone(), p.getGameMode(), p.getHealth(), p.getFoodLevel(),
                p.getSaturation(), p.getExp(), p.getLevel(), new ArrayList<>(p.getActivePotionEffects()), p.getAllowFlight()));
    }

    public boolean join(Player p) {
        if (!joinable()) return false;
        snapshot(p);
        players.add(p.getUniqueId());
        p.leaveVehicle();
        resetPlayer(p, GameMode.ADVENTURE);
        p.teleport(lobby());
        giveLobbyItems(p);
        bar.addPlayer(p);
        attachBoard(p);
        ensureHolo();
        bc("&a" + p.getName() + " &7bergabung &8(" + players.size() + "/" + max + ")");
        Msg.title(p, "&b&l" + name.toUpperCase(), "&7Menunggu pemain lain...", 5, 50, 10);
        Msg.line(p);
        p.sendMessage(Msg.c(" &b&l" + name.toUpperCase()));
        p.sendMessage(Msg.c(" &7" + rules.get(0)));
        p.sendMessage(Msg.c(" "));
        p.sendMessage(Msg.c(" &8\u00bb &fKlik &eAturan Main &funtuk membaca cara bermain"));
        p.sendMessage(Msg.c(" &8\u00bb &fKlik &aVote Mulai &funtuk mempercepat"));
        p.sendMessage(Msg.c(" &8\u00bb &fKlik &bPanggil Teman &funtuk mengajak pemain lain"));
        Msg.line(p);
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.4f);
        world.spawnParticle(Particle.HAPPY_VILLAGER, p.getLocation().add(0, 1, 0), 20, 0.4, 0.6, 0.4, 0);
        for (Player o : online()) if (!o.equals(p)) o.playSound(o.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.2f);
        return true;
    }

    public void leave(Player p) {
        UUID u = p.getUniqueId();
        if (!players.remove(u)) return;
        boolean wasAlive = alive.remove(u);
        lastHit.remove(u);
        votes.remove(u);
        restore(p);
        if (state == State.ENDING || state == State.RESETTING) return;
        bc("&c" + p.getName() + " &7keluar &8(" + players.size() + ")");
        if (state == State.RUNNING) {
            onLeave(p, wasAlive);
            checkWin();
        } else if (state == State.COUNTDOWN && players.size() < min) {
            state = State.WAITING;
        }
    }

    /** Dipanggil kalau pemain mati lewat jalur lain (misal /kill). */
    public void playerDied(Player p) {
        if (state == State.RUNNING && alive.contains(p.getUniqueId())) onOut(p, lastHitter(p), "tewas");
        else p.teleport(state == State.WAITING || state == State.COUNTDOWN ? lobby() : specSpawn());
    }

    protected void resetPlayer(Player p, GameMode gm) {
        p.getInventory().clear();
        p.setGameMode(gm);
        for (PotionEffect e : p.getActivePotionEffects()) p.removePotionEffect(e.getType());
        p.setHealth(p.getMaxHealth());
        p.setFoodLevel(20);
        p.setSaturation(20f);
        p.setExp(0f);
        p.setLevel(0);
        p.setFireTicks(0);
        p.setFallDistance(0f);
        p.setAllowFlight(false);
    }

    protected void restore(Player p) {
        Saved s = saved.remove(p.getUniqueId());
        bar.removePlayer(p);
        detachBoard(p);
        votes.remove(p.getUniqueId());
        plugin.setScale(p, 1.0);
        for (PotionEffect e : p.getActivePotionEffects()) p.removePotionEffect(e.getType());
        p.closeInventory();
        p.setItemOnCursor(null);
        p.getInventory().clear();
        if (s == null) {
            p.setGameMode(GameMode.SURVIVAL);
            p.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
            return;
        }
        p.teleport(s.loc());
        p.setGameMode(s.gm());
        p.getInventory().setContents(s.inv());
        p.setHealth(Math.max(1.0, Math.min(s.hp(), p.getMaxHealth())));
        p.setFoodLevel(s.food());
        p.setSaturation(s.sat());
        p.setExp(s.exp());
        p.setLevel(s.lvl());
        for (PotionEffect e : s.fx()) p.addPotionEffect(e);
        p.setAllowFlight(s.fly() || s.gm() == GameMode.CREATIVE || s.gm() == GameMode.SPECTATOR);
        p.setFireTicks(0);
        p.setFallDistance(0f);
    }

    // ---------- damage ----------
    public void onDamage(EntityDamageEvent e, Player v, Player d) {
        UUID vu = v.getUniqueId();
        if (state != State.RUNNING || !alive.contains(vu)) {
            e.setCancelled(true);
            return;
        }
        EntityDamageEvent.DamageCause c = e.getCause();
        if (c == EntityDamageEvent.DamageCause.VOID) {
            e.setCancelled(true);
            onOut(v, lastHitter(v), "jatuh ke void");
            return;
        }
        if (c == EntityDamageEvent.DamageCause.FALL && !fallDamage) {
            e.setCancelled(true);
            return;
        }
        if (d != null) {
            if (!alive.contains(d.getUniqueId())) {
                e.setCancelled(true);
                return;
            }
            lastHit.put(vu, d.getUniqueId());
            if (!pvp) {
                onHit(e, v, d);
                return;
            }
        } else if (!envDamage && c != EntityDamageEvent.DamageCause.FALL) {
            e.setCancelled(true);
            return;
        }
        if (!e.isCancelled() && v.getHealth() - e.getFinalDamage() <= 0) {
            e.setCancelled(true);
            onOut(v, lastHitter(v), "tewas");
        }
    }

    protected Player lastHitter(Player v) {
        UUID u = lastHit.get(v.getUniqueId());
        if (u == null) return null;
        Player p = Bukkit.getPlayer(u);
        return p != null && players.contains(u) ? p : null;
    }

    // ---------- eliminasi & pemenang ----------
    protected void onOut(Player p, Player killer, String reason) {
        eliminate(p, killer, reason);
    }

    protected void eliminate(Player p, Player killer, String reason) {
        if (!alive.remove(p.getUniqueId())) return;
        String m = killer != null
                ? "&c" + p.getName() + " &7dikalahkan oleh &e" + killer.getName()
                : "&c" + p.getName() + " &7" + reason;
        bc(m + " &8(" + alive.size() + " tersisa)");
        p.getInventory().clear();
        for (PotionEffect e : p.getActivePotionEffects()) p.removePotionEffect(e.getType());
        p.teleport(specSpawn());
        p.setGameMode(GameMode.SPECTATOR);
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_DEATH, 1f, 1f);
        Msg.title(p, "&c&lTERSINGKIR", "&7Posisi #" + (alive.size() + 1), 5, 40, 10);
        checkWin();
    }

    protected void checkWin() {
        if (state != State.RUNNING) return;
        if (alive.size() <= 1) end(alivePlayers());
    }

    protected void end(List<Player> winners) {
        if (state == State.ENDING || state == State.RESETTING) return;
        state = State.ENDING;
        onEnd();
        List<String> ns = new ArrayList<>();
        for (Player w : winners) ns.add(w.getName());
        String names = ns.isEmpty() ? "Tidak ada" : String.join("&7, &a", ns);
        for (Player p : online()) {
            Msg.title(p, "&6&lPEMENANG", "&a" + names, 5, 80, 20);
            Msg.line(p);
            p.sendMessage(Msg.c("  &6&l\u2605 PEMENANG \u2605"));
            p.sendMessage(Msg.c("  &a" + names));
            p.sendMessage(Msg.c("  &7Game: &f" + name + " &8| &7Durasi: &f" + fmtTime(runSecs)));
            p.sendMessage(Msg.c("  &7Terima kasih sudah bermain!"));
            Msg.line(p);
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        }
        List<String> cmds = plugin.getConfig().getStringList("rewards.win");
        for (Player w : winners) {
            w.setGameMode(GameMode.ADVENTURE);
            w.setAllowFlight(true);
            for (int k = 0; k < 4; k++) {
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (w.isOnline()) fireworkAt(w.getLocation());
                }, k * 15L);
            }
            for (String cmd : cmds) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", w.getName()));
        }
        Bukkit.getScheduler().runTaskLater(plugin, this::finish, 140L);
    }

    private void finish() {
        for (Player p : online()) restore(p);
        for (UUID u : players) plugin.manager().forget(u);
        players.clear();
        alive.clear();
        saved.clear();
        votes.clear();
        bar.removeAll();
        state = State.RESETTING;
        onReset();
        for (Entity e : world.getNearbyEntities(new Location(world, cx, by + 20, cz), 130, 120, 130)) {
            if (!(e instanceof Player)) e.remove();
        }
        build(() -> state = State.WAITING);
    }

    // ---------- helper ----------
    protected void bc(String s) {
        for (Player p : online()) p.sendMessage(Msg.c(Msg.PREFIX + s));
    }

    protected void setBar(String text, double prog, BarColor col) {
        bar.setTitle(ChatColor.translateAlternateColorCodes('&', text));
        bar.setProgress(Math.max(0, Math.min(1, prog)));
        bar.setColor(col);
    }

    protected List<Player> online() {
        List<Player> l = new ArrayList<>();
        for (UUID u : players) {
            Player p = Bukkit.getPlayer(u);
            if (p != null) l.add(p);
        }
        return l;
    }

    protected List<Player> alivePlayers() {
        return aliveWhere(u -> true);
    }

    protected List<Player> aliveWhere(Predicate<UUID> f) {
        List<Player> l = new ArrayList<>();
        for (UUID u : alive) {
            if (!f.test(u)) continue;
            Player p = Bukkit.getPlayer(u);
            if (p != null) l.add(p);
        }
        return l;
    }

    protected void spreadRing(List<Player> ps, double radius, double y) {
        int n = ps.size();
        for (int i = 0; i < n; i++) {
            double a = 2 * Math.PI * i / Math.max(1, n);
            double x = cx + 0.5 + Math.cos(a) * radius, z = cz + 0.5 + Math.sin(a) * radius;
            Location l = new Location(world, x, y, z);
            l.setDirection(new Vector(cx + 0.5 - x, 0, cz + 0.5 - z));
            ps.get(i).teleport(l);
        }
    }

    protected ItemStack item(Material m, int amt, String nm, String... lore) {
        ItemStack it = new ItemStack(m, amt);
        ItemMeta mm = it.getItemMeta();
        mm.displayName(Msg.c(nm));
        if (lore.length > 0) {
            List<Component> l = new ArrayList<>();
            for (String s : lore) l.add(Msg.c(s));
            mm.lore(l);
        }
        it.setItemMeta(mm);
        return it;
    }

    protected void fireworkAt(Location loc) {
        Firework fw = (Firework) world.spawnEntity(loc, EntityType.FIREWORK_ROCKET);
        FireworkMeta m = fw.getFireworkMeta();
        m.addEffect(FireworkEffect.builder().withColor(Color.AQUA, Color.WHITE, Color.YELLOW)
                .with(FireworkEffect.Type.BALL_LARGE).withFlicker().build());
        m.setPower(1);
        fw.setFireworkMeta(m);
    }

    protected void sound(Sound s, float vol, float pitch) {
        for (Player p : online()) p.playSound(p.getLocation(), s, vol, pitch);
    }
}
