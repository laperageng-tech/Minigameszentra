package id.zentra.minigames;

import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.boss.BarColor;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Husk;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

import java.util.*;

/**
 * Practice PvP: arena datar luas, tanpa ronde. Pemain memilih kit lewat menu, bisa masuk/keluar kapan saja,
 * respawn instan dengan kit yang sama, ada kill streak dan papan skor.
 */
public final class PracticeGame extends Game {
    private static final int R = 38;
    /** stats: [0]=kill [1]=mati [2]=streak [3]=streak terbaik */
    private final Map<UUID, int[]> stats = new HashMap<>();
    private final Map<UUID, Kit> kits = new HashMap<>();
    private final Map<UUID, Long> shield = new HashMap<>();
    private final Map<UUID, Long> hitTime = new HashMap<>();
    private final Map<Block, Long> placed = new HashMap<>();
    private final Map<UUID, String> names = new HashMap<>();
    private final Map<UUID, Integer> botLevel = new HashMap<>();
    private final Map<UUID, Mob> bots = new HashMap<>();

    public static final String[] LEVELS = {"Mati", "Mudah", "Sedang", "Sulit"};
    public static final String[] LEVEL_COLORS = {"&7", "&a", "&e", "&c"};
    private static final double[] BOT_HP = {0, 20, 30, 40};
    private static final double[] BOT_DMG = {0, 4, 7, 10};
    private static final double[] BOT_SPEED = {0, 0.21, 0.26, 0.30};

    public PracticeGame(ZentraMinigames pl, int inst, int cx, int by, int cz) {
        super(pl, "practice", "Practice PvP", Material.END_CRYSTAL, inst, cx, by, cz, 1,
                Math.max(2, pl.getConfig().getInt("games.practice.max", 40)), List.of(
                        "Arena datar luas untuk latihan PvP bersama banyak pemain.",
                        "Pilih kit lewat menu: Crystal PvP, Mace, Sword, atau NoDebuff.",
                        "Mati = respawn instan dengan kit yang sama (proteksi singkat). Kill beruntun menambah streak.",
                        "Klik item Ganti Kit di hotbar untuk pindah kit, atau Keluar untuk pergi kapan saja."));
        voidY = by - 12;
        pvp = true;
        envDamage = true;
        fallDamage = false;
        canBuild = false;
        lockInv = false;
        continuous = true;
    }

    @Override protected boolean hasLobby() { return false; }
    @Override public Location specSpawn() { return randomSpawn(); }
    @Override public void forceStart() { }
    @Override protected void checkWin() { }
    @Override protected void onStart() { }

    @Override
    public boolean joinable() {
        return open && (state == State.WAITING || state == State.RUNNING) && players.size() < max;
    }

    // ---------- arena ----------
    @Override
    protected void buildArena(Blueprint b) {
        b.cone(cx, by - 4, cz, R, 10, Material.DEEPSLATE);
        b.cylinder(cx, by - 3, by - 1, cz, R, Material.DEEPSLATE_TILES);
        b.disc(cx, by, cz, R, Material.LIGHT_GRAY_CONCRETE);
        b.ring(cx, by, cz, R - 5, R, Material.GRAY_CONCRETE);
        b.ring(cx, by, cz, R - 6, R - 5, Material.CYAN_CONCRETE);
        b.ring(cx, by, cz, 20, 21, Material.CYAN_CONCRETE);
        b.disc(cx, by, cz, 8, Material.WHITE_CONCRETE);
        b.ring(cx, by, cz, 6, 7, Material.CYAN_CONCRETE);
        b.disc(cx, by, cz, 2, Material.SEA_LANTERN);
        for (int h = 1; h <= 7; h++) b.ring(cx, by + h, cz, R - 1, R, Material.LIGHT_BLUE_STAINED_GLASS);
        b.ring(cx, by + 8, cz, R - 1, R, Material.SEA_LANTERN);
        for (int k = 0; k < 8; k++) {
            double a = k * Math.PI / 4;
            int x = cx + (int) Math.round(Math.cos(a) * 24), z = cz + (int) Math.round(Math.sin(a) * 24);
            b.fill(x, by + 1, z, x, by + 4, z, Material.POLISHED_DEEPSLATE);
            b.set(x, by + 5, z, Material.SEA_LANTERN);
        }
    }

    private Location randomSpawn() {
        double a = rnd.nextDouble() * Math.PI * 2;
        double r = Math.sqrt(rnd.nextDouble()) * (R - 6);
        Location l = new Location(world, cx + 0.5 + Math.cos(a) * r, by + 1, cz + 0.5 + Math.sin(a) * r);
        l.setYaw(rnd.nextFloat() * 360f);
        return l;
    }

    // ---------- masuk / ganti kit ----------
    @Override
    public boolean join(Player p) {
        return joinWith(p, Kit.SWORD);
    }

    public boolean joinWith(Player p, Kit kit) {
        if (!joinable()) return false;
        if (state == State.WAITING) { state = State.RUNNING; runSecs = 0; }
        UUID u = p.getUniqueId();
        snapshot(p);
        players.add(u);
        alive.add(u);
        kits.put(u, kit);
        names.put(u, p.getName());
        stats.put(u, new int[4]);
        botLevel.put(u, plugin.manager().botLevel(u));
        p.leaveVehicle();
        bar.addPlayer(p);
        attachBoard(p);
        ensureHolo();
        spawnWithKit(p);
        bc("&a" + p.getName() + " &7masuk dengan kit " + kit.colored() + " &8(" + players.size() + ")");
        Msg.title(p, "&c&lPRACTICE PVP", "&7Kit: " + kit.colored(), 5, 40, 10);
        return true;
    }

    public void changeKit(Player p, Kit kit) {
        UUID u = p.getUniqueId();
        if (!players.contains(u)) return;
        kits.put(u, kit);
        spawnWithKit(p);
        Msg.send(p, "&7Kit diganti ke " + kit.colored() + "&7.");
    }

    private void spawnWithKit(Player p) {
        UUID u = p.getUniqueId();
        Kit kit = kits.getOrDefault(u, Kit.SWORD);
        resetPlayer(p, GameMode.SURVIVAL);
        kit.give(p);
        p.getInventory().setItem(7, plugin.lobbyItem(Material.NETHER_STAR, "&d&lGanti Kit &7(klik kanan)", "kit", "&7Pilih kit lain (respawn)"));
        p.getInventory().setItem(8, plugin.leaveItem());
        p.getInventory().setHeldItemSlot(0);
        p.teleport(randomSpawn());
        int prot = Math.max(0, plugin.getConfig().getInt("games.practice.respawn-protection", 3));
        if (prot > 0) {
            shield.put(u, System.currentTimeMillis() + prot * 1000L);
            Msg.bar(p, "&a\u2714 Proteksi spawn &f" + prot + "s &8| &7serang untuk mencabutnya");
        }
        p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.5f, 1.4f);
        respawnBot(p);
    }

    // ---------- bot latihan (mob Husk) ----------
    public void setBotLevel(Player p, int lvl) {
        UUID u = p.getUniqueId();
        if (!players.contains(u)) return;
        botLevel.put(u, lvl);
        respawnBot(p);
        Msg.send(p, lvl == 0 ? "&7Bot dimatikan." : "&7Bot latihan: " + LEVEL_COLORS[lvl] + LEVELS[lvl] + "&7.");
    }

    private static void attr(LivingEntity e, String key, double v) {
        Attribute a = Registry.ATTRIBUTE.get(NamespacedKey.minecraft(key));
        if (a == null) return;
        AttributeInstance ai = e.getAttribute(a);
        if (ai != null) ai.setBaseValue(v);
    }

    private void removeBot(UUID owner) {
        Mob m = bots.remove(owner);
        if (m != null && m.isValid()) m.remove();
    }

    private Location botSpawn(Location from) {
        double a = rnd.nextDouble() * Math.PI * 2;
        double x = from.getX() + Math.cos(a) * 9, z = from.getZ() + Math.sin(a) * 9;
        double dx = x - (cx + 0.5), dz = z - (cz + 0.5);
        double d = Math.sqrt(dx * dx + dz * dz), lim = R - 4;
        if (d > lim) { x = cx + 0.5 + dx / d * lim; z = cz + 0.5 + dz / d * lim; }
        return new Location(world, x, by + 1, z);
    }

    private void respawnBot(Player p) {
        UUID u = p.getUniqueId();
        removeBot(u);
        int lvl = botLevel.getOrDefault(u, 0);
        if (lvl <= 0 || !players.contains(u)) return;
        Kit kit = kits.getOrDefault(u, Kit.SWORD);
        Husk h = world.spawn(botSpawn(p.getLocation()), Husk.class, m -> {
            m.setPersistent(false);
            m.setRemoveWhenFarAway(false);
            m.setCanPickupItems(false);
            m.setBaby(false);
            m.customName(Msg.c("&c&lBot &8[" + kit.colored() + "&8] " + LEVEL_COLORS[lvl] + LEVELS[lvl]));
            m.setCustomNameVisible(true);
            String tier = (kit == Kit.CRYSTAL || kit == Kit.MACE) ? "NETHERITE" : "DIAMOND";
            EntityEquipment eq = m.getEquipment();
            eq.setHelmet(new ItemStack(Material.valueOf(tier + "_HELMET")));
            eq.setChestplate(new ItemStack(Material.valueOf(tier + "_CHESTPLATE")));
            eq.setLeggings(new ItemStack(Material.valueOf(tier + "_LEGGINGS")));
            eq.setBoots(new ItemStack(Material.valueOf(tier + "_BOOTS")));
            eq.setItemInMainHand(new ItemStack(kit == Kit.MACE ? Material.MACE
                    : kit == Kit.CRYSTAL ? Material.NETHERITE_SWORD : Material.DIAMOND_SWORD));
            attr(m, "max_health", BOT_HP[lvl]);
            attr(m, "attack_damage", BOT_DMG[lvl]);
            attr(m, "movement_speed", BOT_SPEED[lvl]);
            attr(m, "follow_range", 48);
            attr(m, "spawn_reinforcements", 0);
            m.setHealth(BOT_HP[lvl]);
            m.setTarget(p);
        });
        bots.put(u, h);
    }

    /** Bot hanya boleh menyerang pemilik. */
    public boolean allowTarget(Entity bot, LivingEntity target) {
        if (target == null) return true;
        for (Map.Entry<UUID, Mob> en : bots.entrySet()) {
            if (en.getValue().getUniqueId().equals(bot.getUniqueId())) return target.getUniqueId().equals(en.getKey());
        }
        return true;
    }

    public void onBotDeath(EntityDeathEvent e) {
        UUID owner = null;
        for (Map.Entry<UUID, Mob> en : bots.entrySet()) {
            if (en.getValue().getUniqueId().equals(e.getEntity().getUniqueId())) owner = en.getKey();
        }
        if (owner == null) return;
        e.getDrops().clear();
        e.setDroppedExp(0);
        bots.remove(owner);
        Player killer = e.getEntity().getKiller();
        if (killer != null && players.contains(killer.getUniqueId())) {
            int[] ks = stats.computeIfAbsent(killer.getUniqueId(), k -> new int[4]);
            ks[0]++;
            ks[2]++;
            ks[3] = Math.max(ks[3], ks[2]);
            killer.setHealth(killer.getMaxHealth());
            killer.playSound(killer.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.5f);
            Msg.bar(killer, "&a+1 Kill (bot) &8| &7Streak: &6" + ks[2] + " &8| &7Total: &f" + ks[0]);
        }
        final UUID o = owner;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Player op = Bukkit.getPlayer(o);
            if (op != null && players.contains(o)) respawnBot(op);
        }, 40L);
    }

    @Override
    public void shutdown() {
        for (UUID u : new ArrayList<>(bots.keySet())) removeBot(u);
        super.shutdown();
    }

    @Override
    public void lobbyAction(Player p, String id) {
        if (id.equals("kit")) {
            plugin.manager().openKitMenu(p);
            return;
        }
        super.lobbyAction(p, id);
    }

    @Override
    protected void onLeave(Player p, boolean wasAlive) {
        UUID u = p.getUniqueId();
        kits.remove(u);
        shield.remove(u);
        hitTime.remove(u);
        botLevel.remove(u);
        removeBot(u);
    }

    // ---------- damage & kill ----------
    @Override
    public void onDamage(EntityDamageEvent e, Player v, Player d) {
        UUID vu = v.getUniqueId();
        long now = System.currentTimeMillis();
        Long until = shield.get(vu);
        if (until != null) {
            if (now < until) { e.setCancelled(true); return; }
            shield.remove(vu);
        }
        if (d != null) shield.remove(d.getUniqueId());
        if (state != State.RUNNING || !alive.contains(vu)) { e.setCancelled(true); return; }
        EntityDamageEvent.DamageCause c = e.getCause();
        if (d == null && (c == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION || c == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION)) {
            d = nearest(v, 12);
        }
        if (d != null && !d.equals(v) && alive.contains(d.getUniqueId())) {
            lastHit.put(vu, d.getUniqueId());
            hitTime.put(vu, now);
        }
        if (c == EntityDamageEvent.DamageCause.VOID) {
            e.setCancelled(true);
            onOut(v, lastHitter(v), "jatuh ke void");
            return;
        }
        if (c == EntityDamageEvent.DamageCause.FALL) { e.setCancelled(true); return; }
        if (v.getHealth() - e.getFinalDamage() <= 0) {
            if (hasTotem(v)) return; // biarkan totem bekerja secara vanilla
            e.setCancelled(true);
            onOut(v, lastHitter(v), c == EntityDamageEvent.DamageCause.ENTITY_ATTACK ? "dikalahkan bot" : "tewas");
        }
    }

    private boolean hasTotem(Player p) {
        return p.getInventory().getItemInMainHand().getType() == Material.TOTEM_OF_UNDYING
                || p.getInventory().getItemInOffHand().getType() == Material.TOTEM_OF_UNDYING;
    }

    private Player nearest(Player v, double r) {
        Player best = null;
        double bd = r * r;
        for (Player o : online()) {
            if (o.equals(v) || !alive.contains(o.getUniqueId()) || o.getWorld() != v.getWorld()) continue;
            double dd = o.getLocation().distanceSquared(v.getLocation());
            if (dd < bd) { bd = dd; best = o; }
        }
        return best;
    }

    @Override
    protected Player lastHitter(Player v) {
        Long t = hitTime.get(v.getUniqueId());
        if (t == null || System.currentTimeMillis() - t > 12000) return null;
        return super.lastHitter(v);
    }

    @Override
    protected void onOut(Player p, Player killer, String reason) {
        UUID u = p.getUniqueId();
        if (!alive.contains(u)) return;
        int[] s = stats.computeIfAbsent(u, k -> new int[4]);
        s[1]++;
        int lost = s[2];
        s[2] = 0;
        if (killer != null && !killer.equals(p)) {
            int[] ks = stats.computeIfAbsent(killer.getUniqueId(), k -> new int[4]);
            ks[0]++;
            ks[2]++;
            ks[3] = Math.max(ks[3], ks[2]);
            Kit kk = kits.getOrDefault(killer.getUniqueId(), Kit.SWORD);
            bc("&c" + p.getName() + " &7dikalahkan &e" + killer.getName() + " &8[" + kk.colored() + "&8]"
                    + (lost >= 3 ? " &6(streak " + lost + " putus!)" : ""));
            killer.setHealth(killer.getMaxHealth());
            killer.playSound(killer.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.5f);
            Msg.bar(killer, "&a+1 Kill &8| &7Streak: &6" + ks[2] + " &8| &7Total: &f" + ks[0]);
            if (ks[2] >= 3 && ks[2] % 3 == 0) bc("&6\u2605 " + killer.getName() + " &emendapat streak &6" + ks[2] + " &ekill!");
        } else {
            bc("&c" + p.getName() + " &7" + reason);
        }
        lastHit.remove(u);
        hitTime.remove(u);
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_DEATH, 0.7f, 1f);
        Msg.bar(p, "&cKamu mati &8| &7respawn instan...");
        spawnWithKit(p);
    }

    // ---------- blok sementara (obsidian Crystal PvP) ----------
    @Override
    public boolean allowPlace(Block b, Player p) {
        if (kits.get(p.getUniqueId()) != Kit.CRYSTAL || b.getType() != Material.OBSIDIAN) return false;
        placed.put(b, System.currentTimeMillis() + 20000L);
        return true;
    }

    @Override
    public boolean allowBreak(Block b, Player p) {
        return placed.containsKey(b);
    }

    @Override
    protected void onSecond() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<Block, Long>> it = placed.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Block, Long> en = it.next();
            if (now >= en.getValue()) {
                if (en.getKey().getType() == Material.OBSIDIAN) en.getKey().setType(Material.AIR, false);
                it.remove();
            }
        }
        for (Map.Entry<UUID, Mob> en : new ArrayList<>(bots.entrySet())) {
            Player op = Bukkit.getPlayer(en.getKey());
            Mob m = en.getValue();
            if (op == null || !m.isValid()) continue;
            if (m.getTarget() == null || !m.getTarget().equals(op)) m.setTarget(op);
        }
        if (players.isEmpty()) return;
        for (Entity e : world.getNearbyEntities(new Location(world, cx, by + 5, cz), R + 2, 30, R + 2)) {
            if (e instanceof EnderCrystal && e.getTicksLived() > 1200) e.remove();
            else if (e instanceof Item) e.remove();
        }
    }

    @Override
    protected void onReset() {
        for (UUID u : new ArrayList<>(bots.keySet())) removeBot(u);
        placed.clear();
        stats.clear();
        kits.clear();
    }

    // ---------- tampilan ----------
    @Override
    protected String barText() {
        return "&c&lPRACTICE PVP &8| &fPemain: &a" + players.size() + " &8| &7/zm leave untuk keluar";
    }

    @Override
    protected String sidebarTitle() { return "&c&lPRACTICE PVP"; }

    @Override
    protected List<String> sidebar(Player p) {
        UUID u = p.getUniqueId();
        int[] s = stats.getOrDefault(u, new int[4]);
        Kit k = kits.getOrDefault(u, Kit.SWORD);
        List<String> l = new ArrayList<>();
        l.add("&8" + id());
        l.add(" ");
        l.add("&fKit &8\u00bb " + k.colored());
        l.add("&fKill &8\u00bb &a" + s[0] + " &8| &fMati &8\u00bb &c" + s[1]);
        l.add("&fK/D &8\u00bb &e" + String.format("%.2f", s[1] == 0 ? (double) s[0] : s[0] / (double) s[1]));
        l.add("&fStreak &8\u00bb &6" + s[2] + " &8(terbaik " + s[3] + ")");
        l.add(" ");
        int bl = botLevel.getOrDefault(u, 0);
        if (bl > 0) l.add("&fBot &8\u00bb " + LEVEL_COLORS[bl] + LEVELS[bl]);
        l.add("&fPemain &8\u00bb &a" + players.size());
        l.add(" ");
        l.add("&b/zm leave &7= keluar");
        return l;
    }

    @Override
    protected Location holoLoc() { return new Location(world, cx + 0.5, by + 5.5, cz + 0.5); }

    @Override
    protected Component holoText() {
        List<Map.Entry<UUID, int[]>> top = new ArrayList<>(stats.entrySet());
        top.removeIf(en -> !players.contains(en.getKey()));
        top.sort((a, b) -> Integer.compare(b.getValue()[0], a.getValue()[0]));
        StringBuilder sb = new StringBuilder("&c&lPRACTICE PVP\n&8&m               \n&fTop Kill\n");
        if (top.isEmpty()) sb.append("&7Belum ada pemain\n");
        for (int i = 0; i < Math.min(3, top.size()); i++) {
            Map.Entry<UUID, int[]> en = top.get(i);
            sb.append(i == 0 ? "&6" : i == 1 ? "&f" : "&c").append(i + 1).append(". &f")
                    .append(names.getOrDefault(en.getKey(), "?")).append(" &8- &a").append(en.getValue()[0]).append("\n");
        }
        sb.append("&7").append(players.size()).append(" pemain berlatih");
        return Msg.c(sb.toString());
    }
}
